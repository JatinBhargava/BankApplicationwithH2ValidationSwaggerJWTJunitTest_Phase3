package com.fis.bankapplication.model;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
 
 
import org.junit.jupiter.api.Test;
 
 
public class AccountTest {
 
	Account account = new Account();

 
	@Test
	void setAccountNoTest() {
		account.setAccountId(1);
		assertEquals(1, account.getAccountId());
	}
	
	@Test
	void setAccountTypeTest() {
		account.setTypeOfAccount("Savings");
		assertEquals("Savings", account.getTypeOfAccount());
	}
}