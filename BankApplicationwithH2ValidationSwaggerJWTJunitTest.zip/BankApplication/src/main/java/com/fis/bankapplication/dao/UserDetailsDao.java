package com.fis.bankapplication.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.bankapplication.model.DAOUser;

public interface UserDetailsDao extends JpaRepository<DAOUser, Integer>{
	public abstract DAOUser findByUsername(String username);
}