package com.fis.bankapplication.dao;
import com.fis.bankapplication.exception.CustomerNotFoundException;

import com.fis.bankapplication.exception.EmptyField;
import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.model.Customer;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface CustomerDao extends JpaRepository<Customer,Integer>{
	@Modifying
	@Query("UPDATE Customer ba SET ba.name = :newName,ba.address = :newAddress where ba.id = :accountId")
	public abstract void updateCustomer(@Param("accountId") int accountId,@Param("newName") String name,@Param("newAddress") String address) throws CustomerNotFoundException;
}
