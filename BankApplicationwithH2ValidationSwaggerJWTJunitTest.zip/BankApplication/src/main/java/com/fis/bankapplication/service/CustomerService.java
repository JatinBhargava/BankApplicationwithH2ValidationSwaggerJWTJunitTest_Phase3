package com.fis.bankapplication.service;

import java.util.List;
import java.util.Optional;

import com.fis.bankapplication.exception.CustomerNotFoundException;
import com.fis.bankapplication.exception.EmptyField;
import com.fis.bankapplication.model.Customer;

public interface CustomerService {
	public abstract String addUser(Customer customer);
	public abstract void updateCustomer(int customerId,String name,String address) throws CustomerNotFoundException;
	public abstract String deleteUser(int customerId) throws CustomerNotFoundException;
	public abstract Optional<Customer> getUser(int customerId) throws CustomerNotFoundException;
	public abstract List<Customer> getAllCustomer();
}
