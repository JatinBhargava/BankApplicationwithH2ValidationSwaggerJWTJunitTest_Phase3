package com.fis.bankapplication.exception;

public class EmptyField extends Exception {
	public EmptyField(String string) {
		super(string);
	}
}
