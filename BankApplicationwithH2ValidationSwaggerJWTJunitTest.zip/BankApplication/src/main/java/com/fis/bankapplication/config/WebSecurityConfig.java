package com.fis.bankapplication.config;

import java.time.LocalDate;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
//import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.service.AuthorizationScope;

//JWT
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
@EnableSwagger2
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint;

	@Autowired
	private UserDetailsService jwtUserDetailsService;

	@Autowired
	private JwtRequestFilter jwtRequestFilter;

	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		// configure AuthenticationManager so that it knows from where to load
		// user for matching credentials
		// Use BCryptPasswordEncoder
		auth.userDetailsService(jwtUserDetailsService).passwordEncoder(passwordEncoder());
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	@Override
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}

	@Override
	protected void configure(HttpSecurity httpSecurity) throws Exception {
		// We don't need CSRF for this example
		httpSecurity.csrf().disable()
				// dont authenticate this particular request
				.authorizeRequests().antMatchers("/authenticate","/register","/h2-console/**","/",
	                    "/v2/api-docs",           // swagger
	                    "/webjars/**",            // swagger-ui webjars
	                    "/swagger-resources/**",  // swagger-ui resources
	                    "/configuration/**",      // swagger configuration
	                    "/*.html").
				permitAll().antMatchers(HttpMethod.OPTIONS, "/**").permitAll().
				// all other requests need to be authenticated
				anyRequest().authenticated().and().
				// make sure we use stateless session; session won't be used to
				// store user's state.
				exceptionHandling().authenticationEntryPoint(jwtAuthenticationEntryPoint).and().sessionManagement()
				.sessionCreationPolicy(SessionCreationPolicy.STATELESS);
		
		httpSecurity.headers().frameOptions().sameOrigin();

		// Add a filter to validate the tokens with every request
		httpSecurity.addFilterBefore(jwtRequestFilter, UsernamePasswordAuthenticationFilter.class);
	}
	
	 @Bean
	    public Docket api() {
	        return new Docket(DocumentationType.SWAGGER_2)
	        		.select()
	                .paths(PathSelectors.any())
	                .apis(RequestHandlerSelectors
	                        .basePackage("com.fis.bankapplication.controller"))
	                    .paths(PathSelectors.regex("/.*"))
	                    .build().apiInfo(apiEndPointsInfo())
	                    .securitySchemes(Arrays.asList(apiKey()))
	                    .securityContexts(Arrays.asList(securityContext()))
	                    .pathMapping("/")
	                    .useDefaultResponseMessages(false)
	                    .directModelSubstitute(LocalDate.class,String.class)
	                    .genericModelSubstitutes(ResponseEntity.class);
	    }
	 
	 
	 
	    private ApiInfo apiEndPointsInfo() {

	        return new ApiInfoBuilder().title("Spring Boot REST API")
	            .description("Bank Application REST API")
	            .contact(new Contact("SS", "www.fis.net", "fis@gmail.com"))
	            .license("Apache 2.0")
	            .licenseUrl("http://www.apache.org/licenses/LICENSE-2.0.html")
	            .version("1.0.0")
	            .build();
	    }
	    
//	    ApiInfo apiInfo() {
//	        return new ApiInfoBuilder()
//	                .title("Swagger with Spring Boot + Security")
//	                .version("1.0.0")
//	                .description("Your Description")
//	                .contact(new Contact("Contact Name", "Contact_URL","contact@email.com"))
//	                .build();
//	    }
	    
	    private ApiKey apiKey() {
	        return new ApiKey("JWT", "Authorization", "header");
	    }

	    private SecurityContext securityContext() {
	        return SecurityContext.builder()
	        		.securityReferences(defaultAuth())
	        		.build();
	    }

	    private List<SecurityReference> defaultAuth() {
	        AuthorizationScope authorizationScope = new AuthorizationScope("global", "accessEverything");
	        AuthorizationScope[] authorizationScopes = new AuthorizationScope[1];
	        authorizationScopes[0] = authorizationScope;
	        return (List<SecurityReference>) Arrays.asList(new SecurityReference("JWT", authorizationScopes));
	    }
}