package com.fis.bankapplication.service;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapplication.dao.CustomerDao;
import com.fis.bankapplication.exception.CustomerNotFoundException;
import com.fis.bankapplication.exception.EmptyField;
import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.model.Customer;
import com.fis.bankapplication.service.CustomerService;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	private CustomerDao customerDAO;
	
	//add a customer to the database
	@Override
	public String addUser(Customer customer){
			customerDAO.save(customer);
			return "Customer added to the database";
	}

	@Override
	public void updateCustomer(int customerId,String name,String address) throws CustomerNotFoundException {
			customerDAO.updateCustomer(customerId, name, address);
	}

	//delete a user in the database
	@Override
	public String deleteUser(int customerId) throws CustomerNotFoundException{
			customerDAO.deleteById(customerId);
			return "Customer delete with id:" + customerId;
	}
	
	//gets the customers from the database with the help of it's customer id
	@Override
	public Optional<Customer> getUser(int customerId) throws CustomerNotFoundException{
		Optional<Customer> readCustomer = customerDAO.findById(customerId);
		return readCustomer;
	}

	//get all the customers from the database
	@Override
	public List<Customer> getAllCustomer() {
		return customerDAO.findAll();
	}

}
