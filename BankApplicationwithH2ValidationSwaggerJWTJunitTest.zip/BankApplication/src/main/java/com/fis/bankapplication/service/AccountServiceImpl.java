package com.fis.bankapplication.service;

import java.util.List;


import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapplication.dao.AccountDao;
import com.fis.bankapplication.model.Account;

@Service
@Transactional
public class AccountServiceImpl implements AccountService{

	@Autowired
	private AccountDao accountDAO;
	
	//add a account to the database
	@Override
	public String addAccount(Account account) {
			accountDAO.save(account);
			return "Account added to the database";
	}
	
	//get account by it's account Id
	@Override
	public Optional<Account> getAccountByAccountId(int accountId) {
			Optional<Account> readAccount = accountDAO.findById(accountId);
			return readAccount;
	}
	
	//update account's balance
	@Override
	public void updateAccount(int accountId, double amount) {
		accountDAO.updateAccount(accountId, amount);
	}
	
	//delete a account
	public String deleteAccount(int accountId) {
		accountDAO.deleteById(accountId);
		return "Account id deleted: " + accountId;
	}

	//get all accounts between some range
	@Override
	public List<Account> getAllAccountsByBalanceRange(double minBal, double maxBal) {
		return accountDAO.getAllAccountsByBalanceRange(minBal,maxBal);
	}
	
	//retrive all the accounts in the database
	@Override
	public List<Account> getAllAccounts(){
		return accountDAO.findAll();
	}

}
